#4. Write a Python program to count and display the vowels of a given text String=”Welcome to python Training”

# Given string
string = "Welcome to python Training"

# Define vowels
vowels = "aeiou"

# Create a dictionary to store the count of each vowel
vowel_count = {vowel: 0 for vowel in vowels}

# Convert the string to lowercase to make counting case-insensitive
string = string.lower()

# Count the occurrences of each vowel
for char in string:
    if char in vowel_count:
        vowel_count[char] += 1

# Display the count of each vowel
for vowel, count in vowel_count.items():
    print(f"{vowel}: {count}")

#2. Write a Python program to remove a newline in PythonString = "\nBest \nDeeptech \nPython \nTraining\n" ,  with output

# Given string with newlines
string = "\nBest \nDeeptech \nPython \nTraining\n"

# Remove newlines by replacing them with an empty string
cleaned_string = string.replace('\n', '')

# Print the cleaned string
print(cleaned_string)

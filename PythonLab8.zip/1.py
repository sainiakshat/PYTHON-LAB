#1. Write a Python program to count the occurrences of each word in agiven sentence
#string = “To change the overall look of your document. To change the look available in the gallery”

from collections import Counter
import re

# Given sentence
sentence = "To change the overall look of your document. To change the look available in the gallery"

# Convert the sentence to lowercase and remove punctuation
sentence = re.sub(r'[^\w\s]', '', sentence).lower()

# Split the sentence into words
words = sentence.split()

# Count the occurrences of each word
word_count = Counter(words)

# Print the word counts
for word, count in word_count.items():
    print(f"{word}: {count}")

#Q.4 write a code that describe local and global variable with same name follows the roles 

# Global variable

x = 10

def func():
    # Local variable with the same name
    x = 20
    print("Inside func, local x:", x)

func()

print("Outside func, global x:", x)

            #Q.2 describe local variable and global variable code

            #LOCAL VARIABLE 

def f():

    # local variable
    s = "AM Passionate About DATA ANALYST"
    print(s)

# Driver code
f()


            #GLOBAL VARIABLE 


# This function uses global variable s
def f():
    print("Inside Function", s)

# Global scope
s = "KNOW AM INTERN IN MICROSOFT"
f()
print("Outside Function", s)

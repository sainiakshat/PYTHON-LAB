              #Q.5 Write a code for string, int and float input.


s = input("String: ")
i = int(input("Integer: "))
f = float(input("Float: "))

print(s, i, f)

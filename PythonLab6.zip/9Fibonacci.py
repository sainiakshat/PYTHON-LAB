        # Python program to get the Fibonacci series between 0 to 50

# Function to generate the Fibonacci series up to a given limit
def fibonacci_series(limit):
    series = []
    a, b = 0, 1
    while a <= limit:
        series.append(a)
        a, b = b, a + b
    return series

# Generate the Fibonacci series up to 50
fib_series = fibonacci_series(50)

# Print the Fibonacci series
print("Fibonacci series between 0 and 50:")
for num in fib_series:
    print(num, end=" ")

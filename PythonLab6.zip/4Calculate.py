                    #Calculate the sum of numbers from 1 to 10

# Calculate the sum of numbers from 1 to 10
sum_of_numbers = 0
for number in range(1, 11):
    sum_of_numbers += number

# Print the result
print("The sum of numbers from 1 to 10 is:", sum_of_numbers)

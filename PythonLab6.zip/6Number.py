                # Print the first 10 natural numbers using for loop

# Print the first 10 natural numbers
print("The first 10 natural numbers are:")
for number in range(1, 11):
    print(number)

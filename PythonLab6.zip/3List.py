        #Create a list and iterate through its items using a for loop:

# Create a list of items
my_list = ['apple', 'banana', 'cherry', 'date', 'elderberry']

# Iterate through the items in the list
print("List items:")
for item in my_list:
    print(item)

                #l. Print the table of 5 using for loop:

# Python code Multiplication table of 5

number = 5

print("Python code Multiplication Table of {5}")
for i in range(1, 11):
    print(f"{number} x {i} = {number * i}")

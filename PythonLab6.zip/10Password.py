        #Python program to check the validity of password input by users

import re

# Function to check the validity of the password
def is_valid_password(password):
    # Check length of the password
    if len(password) < 8:
        return False
    
    # Check for at least one uppercase letter
    if not re.search(r'[A-Z]', password):
        return False
    
    # Check for at least one lowercase letter
    if not re.search(r'[a-z]', password):
        return False
    
    # Check for at least one digit
    if not re.search(r'[0-9]', password):
        return False
    
    # Check for at least one special character
    if not re.search(r'[@#$%^&+=]', password):
        return False
    
    return True

# Take input from the user
password = input("Enter a password: ")

# Check the validity of the input password
if is_valid_password(password):
    print("The password is valid.")
else:
    print("The password is invalid. It must be at least 8 characters long, contain both uppercase and lowercase letters, have at least one digit, and include at least one special character.")

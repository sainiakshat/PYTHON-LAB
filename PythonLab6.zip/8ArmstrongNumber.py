        # Python program to check if a given number is an Armstrong number

# Function to check if a number is an Armstrong number
def is_armstrong_number(num):
    # Convert the number to a string to easily iterate over digits
    num_str = str(num)
    # Find the number of digits (order)
    order = len(num_str)
    # Calculate the sum of the digits raised to the power of the order
    sum_of_powers = sum(int(digit) ** order for digit in num_str)
    # Check if the sum of powers is equal to the original number
    return num == sum_of_powers

# Take input from the user
number = int(input("Enter a number: "))

# Check if the input number is an Armstrong number
if is_armstrong_number(number):
    print(f"{number} is an Armstrong number.")
else:
    print(f"{number} is not an Armstrong number.")

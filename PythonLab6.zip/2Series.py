            #Print even number series by taking input from the user

# Take input from the user
n = int(input("Enter a number: "))

# Print the series of even numbers
print(f"Even number series up to {n}:")
for i in range(2, n + 1, 2):
    print(i, end=" ")

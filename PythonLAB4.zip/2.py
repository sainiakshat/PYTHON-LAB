                         #Function without Parameters:

    #How do you define and call a function that does not take any arguments?

def greet():
    print("Hello, World!")

greet()                 #CALLING THE FUNCTION


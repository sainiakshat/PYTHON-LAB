                        # Function with Parameter:

            #What are the rules for passing arguments to a function?

                            #Positional Arguments

def greet(name, age):
    print(f"Hello, {name}! You are {age} years old.")

# Calling the function with positional arguments
greet("AKSHATSAINI", 30)
                        
                            # Keyword Arguments

def greet(name, age):
    print(f"Hello, {name}! You are {age} years old.")

# Calling the function with keyword arguments
greet(name="Ashi", age=25)

                            #Default Arguments

def greet(name, age=20):
    print(f"Hello, {name}! You are {age} years old.")

# Calling the function with one argument, using the default value for age
greet("simarpreet")

                        #Variable-Length Arguments

def greet(*names):
    for name in names:
        print(f"Hello, {name}!")

# Calling the function with multiple arguments
greet("Akshatsaini", "Ashi", "Simarpreet")

                #Combining Different Types of Arguments

def greet(greeting, *names, age=20, **info):
    for name in names:
        print(f"{greeting}, {name}! You are {age} years old.")
    for key, value in info.items():
        print(f"{key}: {value}")

# Calling the function with a combination of arguments
greet("Hello", "Akshatsaini", "Ashi", age=25, city="New York", hobby="Reading")




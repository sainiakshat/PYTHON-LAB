                            #Function with Parameter:

    #How can you use parameters to make a function more flexible or reusable? 

def calculate_area(length, width):
    return length * width

# Calling the function with different parameters
area1 = calculate_area(5, 3)
area2 = calculate_area(7, 2)

print(f"Area of rectangle 1: {area1}")
print(f"Area of rectangle 2: {area2}")

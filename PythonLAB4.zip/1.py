                        #1. Function without Parameters:

    #What is a function without parameters, and when might you use one?

def greet():
    print("Hello, World!")

# Calling the function
greet()

                #WHEN WE USE TO FUNCTIONS WITHOUT PARAMETERS 

def initialize_app():
    print("Application initialized!")

initialize_app()

                        #STATUS CHECK OR REPORTING

def print_status():
    print("System is operational.")

print_status()

                            #UTILITY FUNCTIONS 

def print_welcome_message():
    print("Welcome to our service!")

print_welcome_message()

                              #EVENT HANDLERS

def on_click():
    print("Button clicked!")

on_click()

                           #Time-based Functions

def perform_backup():
    print("Backup performed!")

perform_backup()


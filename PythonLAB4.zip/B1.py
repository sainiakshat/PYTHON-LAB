                        #Function with Parameter:

            #How do you define a function that takes parameters?


def greet(name):
    print(f"Hello, {name}!")

# Calling the function with an argument
greet("Akshatsaini")

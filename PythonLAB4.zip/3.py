                         #Function without Parameters:

    #Can a function without parameters return a value? If so, how? in Python.

def get_greeting():
    return "Hello, World!"

        # Calling the function and storing the return value in a variable
greeting = get_greeting()

                    # Printing the return value
print(greeting)

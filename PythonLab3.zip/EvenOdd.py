#1.Write a Python program that takes a number as input and prints "Even" if the number is even and "Odd" if it's odd.




# Function to check if a number is even or odd
def check_even_odd(number):
    if number % 2 == 0:
        return "Even"
    else:
        return "Odd"

# Taking input from the user
try:
    number = int(input("Enter a number: "))
    result = check_even_odd(number)
    print(result)
except ValueError:
    print("Invalid input! Please enter an integer.")

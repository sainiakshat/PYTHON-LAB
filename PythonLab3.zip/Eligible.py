#2.Create a Python program that checks whether a person is eligible to vote (18 years or older) based on their age.

# Function to check if a person is eligible to vote
def check_voter_eligibility(age):
    if age >= 18:
        return "Eligible to vote"
    else:
        return "Not eligible to vote"

# Taking input from the user
try:
    age = int(input("Enter your age: "))
    result = check_voter_eligibility(age)
    print(result)
except ValueError:
    print("Invalid input! Please enter a valid age.")

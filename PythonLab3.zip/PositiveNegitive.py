#4.Create a Python program that checks if a user-given number is positive, negative, or zero.

# Function to check if a number is positive, negative, or zero
def check_number(number):
    if number > 0:
        return "Positive"
    elif number < 0:
        return "Negative"
    else:
        return "Zero"

# Taking input from the user
try:
    number = float(input("Enter a number: "))
    result = check_number(number)
    print(f"The number {number} is {result}.")
except ValueError:
    print("Invalid input! Please enter a valid number.")

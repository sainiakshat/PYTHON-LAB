#5.Write a Python program that determines the largest of three numbers entered by the user.

# Function to determine the largest of three numbers
def find_largest(num1, num2, num3):
    if num1 >= num2 and num1 >= num3:
        return num1
    elif num2 >= num1 and num2 >= num3:
        return num2
    else:
        return num3

# Taking input from the user
try:
    num1 = float(input("Enter the first number: "))
    num2 = float(input("Enter the second number: "))
    num3 = float(input("Enter the third number: "))
    
    largest = find_largest(num1, num2, num3)
    print(f"The largest number is {largest}.")
except ValueError:
    print("Invalid input! Please enter valid numbers.")

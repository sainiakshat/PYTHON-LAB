#Write a python program to reverse a number using a while loop., in python with output

## Accept a number from the user
number = int(input("Enter a number: "))

# Initialize variables
reverse = 0
temp = number

# Reverse the number using a while loop
while temp > 0:
    digit = temp % 10
    reverse = reverse * 10 + digit
    temp = temp // 10

# Display the reversed number
print("The reversed number is:", reverse)

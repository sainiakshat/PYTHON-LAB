#2. Write a python program to check whether a number is palindrome or not?, in python with output 

# Accept a number from the user
number = int(input("Enter a number: "))

# Store the original number
original_number = number

# Initialize a variable to store the reversed number
reverse = 0

# Reverse the number using a while loop
while number > 0:
    digit = number % 10
    reverse = reverse * 10 + digit
    number = number // 10

# Check if the original number is equal to the reversed number
if original_number == reverse:
    print("The number is a palindrome.")
else:
    print("The number is not a palindrome.")

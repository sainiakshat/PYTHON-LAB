#3. Write a python program finding the factorial of a given number using a while loop.

# Accept a number from the user
number = int(input("Enter a number: "))

# Initialize variables
factorial = 1
n = number

# Calculate factorial using a while loop
while n > 0:
    factorial *= n
    n -= 1

# Display the result
print("The factorial of", number, "is:", factorial)

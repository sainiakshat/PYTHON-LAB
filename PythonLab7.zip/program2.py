#2. Write a Python program to remove duplicate characters of a given string.

 #Input = “String and String Function” 

 #Output: String and Function

input_string = "String and String Function"

# Initialize an empty string to store the result
result_string = ""

# Iterate over each character in the input string
for char in input_string:
    if char not in result_string:
        result_string += char

# Print the result
print(result_string)

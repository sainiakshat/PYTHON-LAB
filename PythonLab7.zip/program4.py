#4. Write a Python Count vowels in a string 

#input= “Welcome to Python Assignment” 

#Output: Total vowels are: 8

input_string = "Welcome to Python Assignment"

# Define the vowels
vowels = "aeiouAEIOU"

# Initialize the vowel count
vowel_count = 0

# Iterate over each character in the string
for char in input_string:
    if char in vowels:
        vowel_count += 1

# Print the result
print(f"Total vowels are: {vowel_count}")

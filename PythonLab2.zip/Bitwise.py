        #Q.4 Write a program to calculate greatest of three numbers.

# Define two numbers
a = 10  # In binary: 1010
b = 4   # In binary: 0100

# Perform bitwise operations and print results
print(f"{a} & {b} = {a & b}")  # Bitwise AND
print(f"{a} | {b} = {a | b}")  # Bitwise OR
print(f"{a} ^ {b} = {a ^ b}")  # Bitwise XOR
print(f"~{a} = {~a}")          # Bitwise NOT
print(f"{a} << 1 = {a << 1}")  # Left shift
print(f"{a} >> 1 = {a >> 1}")  # Right shift

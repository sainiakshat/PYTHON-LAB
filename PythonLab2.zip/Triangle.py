                    #2.Calculate the area of a triangle.

# Input base and height of the triangle
base = float(input("Enter the base of the triangle: "))
height = float(input("Enter the height of the triangle: "))

# Calculate the area
area = 0.5 * base * height

# Output the area
print(f"The area of the triangle with base {base} and height {height} is {area:.2f}")

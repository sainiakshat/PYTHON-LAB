                    #4.Calculate the area of a square.

# Input the side length of the square
side = float(input("Enter the side length of the square: "))

# Calculate the area
area = side ** 2

# Output the area
print(f"The area of the square with side length {side} is {area:.2f}")

                        #1.Calculate the area of a circle.

import math

# Function to calculate the area of a circle
def calculate_area(radius):
    return math.pi * radius ** 2

# Input the radius
radius = float(input("Enter the radius of the circle: "))

# Calculate the area
area = calculate_area(radius)

# Output the area
print(f"The area of the circle with radius {radius} is {area:.2f}")

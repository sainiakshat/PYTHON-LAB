                #3.Calculate the area of a rectangle.

# Input width and height of the rectangle
width = float(input("Enter the width of the rectangle: "))
height = float(input("Enter the height of the rectangle: "))

# Calculate the area
area = width * height

# Output the area
print(f"The area of the rectangle with width {width} and height {height} is {area:.2f}")

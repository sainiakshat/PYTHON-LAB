#

# Input three numbers
a = float(input("Enter the first number: "))
b = float(input("Enter the second number: "))
c = float(input("Enter the third number: "))

# Find the greatest number
greatest = max(a, b, c)

# Output the greatest number
print(f"The greatest number among {a}, {b}, and {c} is {greatest}")

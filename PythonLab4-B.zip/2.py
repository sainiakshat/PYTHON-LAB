# Declare a square() function with one parameter.Then call the function and pass one number and display the square of that number .

# Define the square function
def square(x):
    # Return the square of the number
    return x * x

# Call the function with one number
result = square(7)

# Display the result
print("The square of the number is:", result)

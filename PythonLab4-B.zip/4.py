# 4. Accept a name from the user and display that in lower case using lower() function

# Accept a name from the user
name = input("Enter your name: ")

# Convert the name to lowercase
lowercase_name = name.lower()

# Display the name in lowercase
print("Your name in lowercase is:", lowercase_name)


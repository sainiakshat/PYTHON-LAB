# Declare a div() function with two parameters. Then call the function and pass two numbers and display their division.

# Define the div function
def div(a, b):
    # Return the result of dividing a by b
    return a / b

# Call the function with two numbers
result = div(20, 4)

# Display the result
print("The result of the division is:", result)

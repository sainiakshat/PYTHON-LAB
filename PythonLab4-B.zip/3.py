#3. Using max() and min() functions display the maximum and minimum of 5 random numbers. , in python with output

# Define a list of 5 random numbers
numbers = [12, 45, 7, 89, 23]

# Find the maximum number
max_number = max(numbers)

# Find the minimum number
min_number = min(numbers)

# Display the results
print("The maximum number is:", max_number)
print("The minimum number is:", min_number)
